OS X JetCreator Library Build Instructions

1/ Open easwt_vst_lib.xcodeproj and build

2/ Open EASLIb.xcodeproj and build

3/ Copy build/Release/libEASLIb.dylib to the JetCreator folder


