#pragma once

#define ALOGE(...)
#define ALOGW(...)
#define android_errorWriteLog(...)

#define false 0
